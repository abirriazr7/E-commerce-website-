from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import stripe
import os
from datetime import datetime
from werkzeug.utils import secure_filename
from PIL import Image
import io
from flask_paginate import Pagination, get_page_parameter

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

stripe.api_key = 'your_stripe_secret_key_here'

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    addresses = db.relationship('Address', backref='user', lazy=True)
    orders = db.relationship('Order', backref='user', lazy=True)
    wishlist = db.relationship('Wishlist', backref='user', lazy=True)

class Address(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    street = db.Column(db.String(200), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    zip_code = db.Column(db.String(20), nullable=False)
    country = db.Column(db.String(100), default='USA')

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    products = db.relationship('Product', backref='category', lazy=True)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    image = db.Column(db.String(150))
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    reviews = db.relationship('Review', backref='product', lazy=True)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    address_id = db.Column(db.Integer, db.ForeignKey('address.id'), nullable=False)
    total = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(50), default='Pending')
    date = db.Column(db.DateTime, default=datetime.utcnow)
    items = db.relationship('OrderItem', backref='order', lazy=True)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)

class Wishlist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def save_image(form_image):
    if form_image:
        img = Image.open(form_image)
        img.thumbnail((300, 300))
        filename = secure_filename(form_image.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        img.save(filepath)
        return f"uploads/{filename}"
    return None

# Routes
@app.route('/')
@app.route('/search')
def home():
    page = request.args.get(get_page_parameter(), type=int, default=1)
    query = request.args.get('q', '')
    category_id = request.args.get('category', '')
    products = Product.query
    if query:
        products = products.filter(Product.name.ilike(f'%{query}%') | Product.description.ilike(f'%{query}%'))
    if category_id:
        products = products.filter_by(category_id=category_id)
    pagination = products.paginate(page=page, per_page=12, error_out=False)
    categories = Category.query.all()
    return render_template('index.html', products=pagination.items, pagination=pagination, categories=categories, query=query, category_id=category_id)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        user = User(username=username, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful!')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('home'))
        flash('Login failed. Check credentials.')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/profile')
@login_required
def profile():
    addresses = current_user.addresses
    orders = current_user.orders
    return render_template('profile.html', addresses=addresses, orders=orders)

@app.route('/add_address', methods=['GET', 'POST'])
@login_required
def add_address():
    if request.method == 'POST':
        address = Address(
            user_id=current_user.id,
            street=request.form['street'],
            city=request.form['city'],
            state=request.form['state'],
            zip_code=request.form['zip_code'],
            country=request.form['country']
        )
        db.session.add(address)
        db.session.commit()
        flash('Address added!')
        return redirect(url_for('profile'))
    return render_template('add_address.html')

@app.route('/product/<int:id>')
def product_detail(id):
    product = Product.query.get_or_404(id)
    reviews = product.reviews
    is_in_wishlist = Wishlist.query.filter_by(user_id=current_user.id if current_user.is_authenticated else 0, product_id=id).first() if current_user.is_authenticated else False
    return render_template('product.html', product=product, reviews=reviews, is_in_wishlist=is_in_wishlist)

@app.route('/add_to_wishlist/<int:product_id>', methods=['POST'])
@login_required
def add_to_wishlist(product_id):
    if not Wishlist.query.filter_by(user_id=current_user.id, product_id=product_id).first():
        wishlist = Wishlist(user_id=current_user.id, product_id=product_id)
        db.session.add(wishlist)
        db.session.commit()
        flash('Added to wishlist!')
    return redirect(url_for('wishlist'))

@app.route('/wishlist')
@login_required
def wishlist():
    wishlist_items = current_user.wishlist
    products = [item.product for item in wishlist_items]
    return render_template('wishlist.html', products=products)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    if 'cart' not in session:
        session['cart'] = []
    if product_id not in session['cart']:
        session['cart'].append(product_id)
        session.modified = True
    flash('Product added to cart!')
    return redirect(url_for('home'))

@app.route('/cart')
@login_required
def cart():
    if 'cart' in session:
        products = Product.query.filter(Product.id.in_(session['cart'])).all()
        return render_template('cart.html', products=products)
    return render_template('cart.html', products=[])

@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
@login_required
def remove_from_cart(product_id):
    if 'cart' in session:
        session['cart'].remove(product_id)
        session.modified = True
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    addresses = current_user.addresses
    if request.method == 'POST':
        address_id = request.form['address_id']
        if 'cart' in session:
            total = sum(Product.query.get(pid).price for pid in session['cart'])
            order = Order(user_id=current_user.id, address_id=address_id, total=total)
            db.session.add(order)
            db.session.flush()
            for pid in session['cart']:
                order_item = OrderItem(order_id=order.id, product_id=pid, quantity=1, price=Product.query.get(pid).price)
                db.session.add(order_item)
            db.session.commit()
            session.pop('cart', None)
            try:
                intent = stripe.PaymentIntent.create(
                    amount=int(total * 100),
                    currency='usd',
                    metadata={'order_id': order.id}
                )
                return render_template('checkout.html', client_secret=intent.client_secret, order=order)
            except Exception as e:
                flash(str(e))
        return redirect(url_for('order_history'))
    return render_template('checkout.html', addresses=addresses)

@app.route('/order_history')
@login_required
def order_history():
    orders = current_user.orders.order_by(Order.date.desc()).all()
    return render_template('order_history.html', orders=orders)

@app.route('/order/<int:order_id>')
@login_required
def order_detail(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        return redirect(url_for('home'))
    address = order.address
    return render_template('order_detail.html', order=order, address=address)

@app.route('/track_order/<int:order_id>')
@login_required
def track_order(order_id):
    order = Order.query.get_or_404(order_id)
    if order.user_id != current_user.id:
        return redirect(url_for('home'))
    status = "Delivered" if order.status == 'Completed' else "In Transit"
    return render_template('track.html', order=order, status=status)

@app.route('/add_review/<int:product_id>', methods=['POST'])
@login_required
def add_review(product_id):
    rating = int(request.form['rating'])
    comment = request.form['comment']
    review = Review(user_id=current_user.id, product_id=product_id, rating=rating, comment=comment)
    db.session.add(review)
    db.session.commit()
    flash('Review added!')
    return redirect(url_for('product_detail', id=product_id))

@app.route('/ai_help', methods=['GET', 'POST'])
def ai_help():
    if request.method == 'POST':
        query = request.form['query']
        response = f"AI Assistant: Based on your query '{query}', here's some help: Check our FAQ or contact support."
        return render_template('ai_help.html', response=response)
    return render_template('ai_help.html')

@app.route('/admin/add_product', methods=['GET', 'POST'])
@login_required
def add_product():
    if not current_user.is_admin:
        return redirect(url_for('home'))
    categories = Category.query.all()
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        price = float(request.form['price'])
        category_id = request.form['category_id']
        image_file = request.files.get('image')
        image_path = save_image(image_file)
        product = Product(name=name, description=description, price=price, category_id=category_id, image=image_path)
        db.session.add(product)
        db.session.commit()
        flash('Product added!')
        return redirect(url_for('home'))
    return render_template('add_product.html', categories=categories)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        if not Category.query.first():
            cats = [Category(name='Electronics'), Category(name='Books')]
            db.session.add_all(cats)
            db.session.commit()
            products = [
                Product(name='Laptop', description='Great laptop', price=999.99, category_id=1, image='uploads/sample_laptop.jpg'),
                Product(name='Book', description='Interesting book', price=19.99, category_id=2, image='uploads/sample_book.jpg')
            ]
            db.session.add_all(products)
            db.session.commit()
    app.run(debug=True)
