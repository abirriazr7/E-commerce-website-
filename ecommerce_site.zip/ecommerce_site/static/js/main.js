document.addEventListener('DOMContentLoaded', () => {
    console.log('Dynamic site loaded');
    const searchForm = document.querySelector('form[action="/"]');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            // Placeholder for AJAX search
        });
    }
});
