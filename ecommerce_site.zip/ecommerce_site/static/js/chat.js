document.addEventListener('DOMContentLoaded', () => {
    console.log('Chat ready');
    // Placeholder for WebSocket or real-time chat
});
